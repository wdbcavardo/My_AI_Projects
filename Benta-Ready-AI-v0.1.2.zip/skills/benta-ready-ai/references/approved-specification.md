# READY-TO-BUILD — Benta-Ready for New Online Sellers with AI

## 0. ABC BUILD HANDOFF
**Builder:** Warrene Deck Cavardo  
**Product:** Benta-Ready for New Online Sellers with AI  
**Basic descriptor:** Guided AI assistant plus Google Sheets-compatible seven-day Facebook planner.  
**Approved evidence:** Week 3 signature process Approval #1 and MTV Approval #2, followed by final blueprint and branding confirmation in chat.  
**Source:** Uploaded seven-page JIMBO Offer Journal; Product Blueprint V15.1 ZIP.  
**Status:** SPECIFICATION APPROVED; implementation and testing NOT RUN.  
**Build approach:** Create a new guided AI assistant configuration and spreadsheet template; reuse and improve any actual source files only after inspecting them. Do not claim a deployed skill already exists.

## 1. JIMBO PRODUCT INFORMATION
**Original JIMBO product name:** Benta-Ready for New Online Sellers with AI.  
**Exact offer:** “I help new online sellers go from product idea to a ready-to-post offer and first week of content in 3 simple steps using AI.”  
**Buyer:** New online sellers, including home-based sellers, unsure what to sell or post.  
**Transformation:** Idea + random tutorials + blank posting days → clear offer + first week of AI-assisted, human-reviewed posts.  
**Core inclusions:** Step-by-step guide and worksheet; one short Taglish video; Google Sheets content-week planner with AI prompts.  
**First-20 bonuses:** Taglish Messenger Reply Templates and Beta Tester Group Chat.  
**Founding offer:** ₱599 one-time payment for 12 months of access; free Step 1 preview and worked sample; payment and access details via Messenger after buyer confirms. Payment mechanism and terms must be finalized before public enrollment. No income guarantee.  
**Product design:** primary #1168A8, secondary #15324D, accent #25A99A, background #F5F8FC, surface #FFFFFF, text #15324D, muted #52677C, border #D9E4ED, success #18794E, warning #9A6700, error #B42318. Inter/Arial fonts; minimal modern Filipino small-business style.

## 2. MY APPROVED PROLIFIC SIGNATURE PROCESS
### CHOOSE
- **INPUT:** Product idea, selling location, selling price or estimate.
- **ACTION:** Ask the three questions in simple Taglish, one at a time or together; allow 'not sure' for price and label it unknown. Confirm the collected details.
- **OUTPUT:** A concise, editable product brief with all three fields.
- **REVIEW:** Customer confirms or corrects the brief; never invent a missing price or exact location.

### BUILD WITH AI
- **INPUT:** Confirmed brief and product constraints.
- **ACTION:** Suggest three distinct plausible buyer groups, each with needs and buying motivations; label them hypotheses, not verified research. Explain the recommended starting group and let the buyer choose. Draft a clear offer for that buyer and ask for approval.
- **OUTPUT:** One selected buyer profile and one approved offer with product, audience, value, price (if known), and a truthful next action.
- **REVIEW:** Customer approves or revises buyer and offer before proceeding; no unsupported demand rankings, invented research, guarantees, or testimonials.

### PLAN
- **INPUT:** Approved buyer and offer.
- **ACTION:** Write seven complete ready-to-edit Taglish Facebook posts: day, goal, hook, full caption, CTA, suggested visual, and posting checklist. Show all seven for review; offer revision of a day or all days. Export an editable .xlsx spreadsheet if file tools exist.
- **OUTPUT:** Seven distinct Facebook posts plus a downloadable Google Sheets-compatible planner when supported.
- **REVIEW:** Customer checks accuracy and edits claims; verify all seven rows and column headings. If file creation unavailable, supply a clean copy-paste table/CSV and explain how to import it into Sheets.

**Supporting flow — spreadsheet export**  
- **INPUT:** Customer-approved seven-day plan.  
- **ACTION:** Write the plan into a downloadable XLSX if supported; otherwise provide import-ready content.  
- **OUTPUT:** Seven editable rows with ten named columns.  
- **REVIEW:** Reopen/check file, row count and content; guide manual import if blocked.

## 3. FULL OFFER VS. WEEK 3 MTV
**Week 3 MTV NOW:** ChatGPT Skill/assistant + Google Sheets-compatible XLSX export; product/location/price inputs; three potential buyer groups; user chooses buyer and approves offer; seven complete Taglish Facebook posts (goal, hook, caption, CTA, visual, checklist); five-beginner pilot.  
**Promised full offer to finish:** Step-by-step guide and worksheet, one short Taglish video, planner with AI prompts, free Step 1 preview, one worked sample, first-20 Taglish Messenger templates and beta tester chat, fulfillment/access/payment setup.  
**LATER:** Automatic Google Sheets sync, automatic Facebook publishing, live market/competitor research, multi-platform posting, advanced analytics, marketplace and checkout automation.  
**Screen/message map:** Welcome & Inputs → Confirm Brief → Three Buyer Options → Select Buyer & Approve Offer → Review Seven Posts → Download/Import Help.  
**Spreadsheet schema:** Day (1–7), Goal, Hook, Full Taglish Caption, CTA, Suggested Visual, Posting Checklist, Planned Date (blank), Status (Draft/Ready/Posted, initial Draft), Notes. No date or claim fabrication.  
**Worked example:** Ube Cheese Pandesal, Cagayan de Oro, ₱250/12; three hypothetical groups busy moms / office employees / event organizers; customer may select any. No real research was performed.

## 4. DEFINITION OF DONE + HONEST STATUS
**Definition of done:** Working three-stage interactive assistant; approval checkpoints; seven complete distinct editable posts; XLSX import/reopen verified when tools permit; honest fallback if not; source inclusions tracked; five-beginner pilot feedback collected before declaring validated.  
**Current honest status:** Blueprint APPROVED; skill installation NOT RUN; spreadsheet generation NOT RUN; external integration NOT RUN; real buyer tests NOT RUN; payment and access verification NOT RUN.  
**Permissions:** Never publish, send messages, collect payment, access private accounts or use paid services without explicit permission.

## 5. ABC BUILDING PROMPT (SELECTED + FULLY CUSTOMIZED)
Copy the following full prompt into a capable ChatGPT Skill/configuration builder, or give it to a building assistant with file-writing support.

```text
You are the Benta-Ready AI guided assistant for Filipino beginner online sellers. Build and/or configure a real usable assistant, not merely a marketing description. Product name: Benta-Ready for New Online Sellers with AI. Buyer: new or home-based online seller with a product idea. Preserve the JIMBO guide/worksheet, one short Taglish video, Google Sheets planner with AI prompts, and first-20 bonuses as full-offer deliverables.

Three-stage mandatory process:
### CHOOSE
- **INPUT:** Product idea, selling location, selling price or estimate.
- **ACTION:** Ask the three questions in simple Taglish, one at a time or together; allow 'not sure' for price and label it unknown. Confirm the collected details.
- **OUTPUT:** A concise, editable product brief with all three fields.
- **REVIEW:** Customer confirms or corrects the brief; never invent a missing price or exact location.

### BUILD WITH AI
- **INPUT:** Confirmed brief and product constraints.
- **ACTION:** Suggest three distinct plausible buyer groups, each with needs and buying motivations; label them hypotheses, not verified research. Explain the recommended starting group and let the buyer choose. Draft a clear offer for that buyer and ask for approval.
- **OUTPUT:** One selected buyer profile and one approved offer with product, audience, value, price (if known), and a truthful next action.
- **REVIEW:** Customer approves or revises buyer and offer before proceeding; no unsupported demand rankings, invented research, guarantees, or testimonials.

### PLAN
- **INPUT:** Approved buyer and offer.
- **ACTION:** Write seven complete ready-to-edit Taglish Facebook posts: day, goal, hook, full caption, CTA, suggested visual, and posting checklist. Show all seven for review; offer revision of a day or all days. Export an editable .xlsx spreadsheet if file tools exist.
- **OUTPUT:** Seven distinct Facebook posts plus a downloadable Google Sheets-compatible planner when supported.
- **REVIEW:** Customer checks accuracy and edits claims; verify all seven rows and column headings. If file creation unavailable, supply a clean copy-paste table/CSV and explain how to import it into Sheets.

Interaction: start with a warm concise Taglish welcome. Ask for (1) product idea, (2) where it will be sold, (3) selling price or estimated price; allow unknown price. Confirm brief. Suggest THREE differentiated plausible buyer groups with buyer needs, motivations, reasons, and one recommended starting hypothesis. Explicitly mark all inferred segments as unverified hypotheses unless external sources were actually accessed and cited. Wait for user buyer selection. Draft a simple offer with what, for whom, why it helps, truthful price if known, and CTA. Wait for explicit offer approval. Only then generate SEVEN DISTINCT complete ready-to-edit Facebook posts. Each day includes day number, goal, hook, full Taglish caption, CTA, suggested real photo/visual, and posting checklist. Avoid fabricated testimonials, market data, guaranteed earnings, discounts, delivery or availability.

Export: if file creation is available, produce an editable XLSX with exactly seven day rows and columns Day, Goal, Hook, Full Taglish Caption, CTA, Suggested Visual, Posting Checklist, Planned Date, Status, Notes. Planned Date blank unless given; Status defaults Draft. Verify row count, editable cells, text wrapping, and import into Google Sheets. If unavailable, clearly state this and give tab-separated/CSV content and instructions to paste/import into Sheets. Never claim a file or integration exists when it does not.

Product design: primary #1168A8, secondary #15324D, accent #25A99A, background #F5F8FC, surface #FFFFFF, text #15324D, muted #52677C, border #D9E4ED, success #18794E, warning #9A6700, error #B42318; Inter/Arial sans-serif, clear labels, 16px+ screen body, spacious layouts, no flashy gradients. Touchpoint order: Welcome/Input -> Confirm Brief -> Buyer Options -> Offer Approval -> Seven-Day Plan -> Export/Help. Each screen/message has a clear next action, revise/back option, and honest errors.

Build NOW: interactive prompt/configuration, seven-post planner, editable spreadsheet template, Step 1 guide/worksheet draft, worked example and five-tester checklist. Build LATER: direct Sheets sync, automatic publishing, real-time competitor intelligence, multi-platform marketing, marketplace, automated checkout. Do not claim these work.

Test three briefs (normal priced product, unknown price, missing export tool); inspect outputs, verify seven distinct posts and spreadsheet readback when supported. Record all tests as NOT RUN until executed. Do not deploy, spend money, publish, send messages or handle real payments without explicit authorization. Report files actually created, tested behaviors, unresolved permissions, and owner-provided assets.
```

**Expected generated assets:** usable skill instructions/configuration; Google Sheets-compatible XLSX template; Step 1 guide/worksheet draft; short demo script outline; worked example; test log. Only mark an asset created after a real file exists. The final paid video and bonuses remain owner-produced/reviewed launch tasks.

## 6. TEST CASES - PLANNED, NOT CLAIMED PASSED
All cases start **NOT RUN**. A PASS requires observed result and evidence; screenshots alone do not prove spreadsheet editability.

| Case | Preconditions | Steps | Expected | Evidence / readback | Observed | Status |
|---|---|---|---|---|---|---|
| Normal complete brief | Product, city and price supplied | Complete flow, approve buyer and offer, export planner | Three buyer options; one approved offer; seven distinct posts and seven editable spreadsheet rows | Chat transcript and spreadsheet row/readback | — | NOT RUN |
| Missing price | Customer enters 'not sure' | Complete process without price | No invented price; captions avoid numeric price | Transcript and output review | — | NOT RUN |
| Change buyer | Customer chooses nonrecommended segment | Revise offer and posts | All seven posts target selected segment, not initial recommendation | Before/after comparison | — | NOT RUN |
| No file capability | File generation unavailable | Request export | Honest limitation, copy-paste table/CSV, import steps | Fallback text and Google Sheets paste test | — | NOT RUN |
| Unsafe claims | Product has no testimonials or delivery promise | Generate seven posts | No fabricated review, stock, shipping, guarantee or sales figures | Manual claim audit | — | NOT RUN |
| Usability and visual design | New tester starts from welcome | Complete on phone/desktop if available | Readable, clear next action, approved colors/fonts in visual assets | Tester observation and screenshots | — | NOT RUN |
| Full offer integrity | Review original JIMBO inclusions | Compare planned launch checklist | Guide, worksheet, video, planner, two bonuses and access terms all accounted for | Source-to-deliverable checklist | — | NOT RUN |

**Three real-user missions (five beginners total):** (1) standard product → seven posts → XLSX import; (2) unknown price and buyer change → revised offer/posts; (3) no-file fallback → manual Sheets import. Ask all five for ease-of-use, relevance, clarity, editability and improvement feedback. Record real observations only.

## 7. START BUILDING / FIRST TEST / RECOVERY
1. Open a ChatGPT environment that supports building/configuring a custom assistant or skill; attach this Markdown and the JIMBO Journal. Ask it to implement the complete prompt in Section 5. Do not assume a ZIP automatically installs as a public plugin.
2. First build the guided conversation and test the sample Ube Cheese Pandesal brief; confirm three buyer options, explicit approval, seven complete posts.
3. Create and open the XLSX in Google Sheets; verify seven day rows, editable captions and statuses. If tools are unavailable, test the copy/paste fallback.
4. Recruit five consenting beginners, observe their sessions and record the Section 6 evidence. Fix blocking usability issues before launch.
5. Finish the guide, worksheet, video, preview, Messenger templates, beta group, price/12-month access terms, payment instructions and support channel before taking payments.

**Business owner must provide before launch:** Verified sample/product facts and any real photos; final video narration/recording; payment details; distribution/access mechanism for 12 months; beta chat and customer-support arrangements; consented tester feedback. No credentials or customer data should be embedded in this handoff.  
**If blocked:** Missing file generation → use manual import fallback and record limitation; no external research → label segments hypotheses; missing payment/access configuration → do not open paid enrollment; no plugin-install permissions → deliver tested instructions and assets rather than claiming installation.  
**Release checklist:** Buyer promise and claims verified; all original inclusions present; free preview works; price/term clearly disclosed; actual payment and access tested with authorization; content and spreadsheet reviewed; pilot feedback recorded.
