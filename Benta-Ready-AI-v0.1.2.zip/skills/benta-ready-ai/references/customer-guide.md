# Customer quick start and Step 1 worksheet
Open the selected Benta-Ready AI assistant and say “Start Benta-Ready AI.”
Supply: product idea; sales platform and target location; price, range, estimate or unknown.
Confirm the summary, choose one of three hypothetical buyer groups, then review and approve the offer.
Review seven posts; request changes or approve. Download the actual XLSX if supported, or use the CSV/TSV fallback.
Import XLSX into Google Sheets using File > Import > Upload. Check seven rows and all captions; add dates and edit statuses.
Attach actual photos, verify prices/stock/details, then post manually on Facebook.

## Blank worksheet
Product:
Target location:
Sales platform:
Price/range and unit (or unknown):
Verified features:
Unknown details:
Selected buyer:
Approved offer:

## Worked example (hypothetical)
Product: Ube Cheese Pandesal. Location: Cagayan de Oro. Price: ₱250 per 12.
Possible groups: busy moms, office employees, event organizers. These are hypotheses, not verified research.
Pause for the customer's own buyer choice and offer approval before creating posts.

## Short Taglish demo video outline (not a recorded video)
Show input of product/location/price; confirm brief; show three hypotheses and buyer choice; approve offer; review seven captions; export and edit dates; demonstrate manual photo/claim review and posting.

