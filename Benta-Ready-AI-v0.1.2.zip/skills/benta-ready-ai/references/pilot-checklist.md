# Owner pilot and launch checklist
Package validation is not customer validation.
Test: complete priced brief; unknown price; nonrecommended buyer choice; buyer change; missing export tools; unsupported product claims; restart/new customer identity.
Check each confirmation gate, exactly three groups and seven distinct complete posts, selected audience consistency, no fabricated facts.
For export, reopen XLSX and verify seven editable data rows and ten exact headers. Record native Sheets import as NOT RUN unless actually tested.
Recruit five consenting beginners. Record ease, relevance, clarity, editability, improvements and actual evidence.
Before paid enrollment: finish/review guide and worksheet, recorded Taglish video, planner with prompts, Step 1 preview, worked example, first-20 Messenger templates, beta tester group, payment instructions, support and 12-month customer access mechanism.
This plugin has no access enforcement or checkout. Do not advertise those as implemented.

